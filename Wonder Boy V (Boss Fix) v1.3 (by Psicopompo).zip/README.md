# Wonder Boy V (Boss Fix) v1.3

**Final boss patch for *Wonder Boy in Monster World* (Mega Drive / Genesis)**
by **Psicopompo**.

Restores the western (UE) final boss to the Japanese version: **no saw running
across the floor and no conveyor belt** dragging you around.

The lasers, their rail, the boss armour and everything else are **untouched**:
those were already the same in both versions.


## What is in this package

Two patches, both applied to the **same clean ROM**:

| Patch | What it does |
|---|---|
| **(A)** `... v1.3 (by Psicopompo)` | The final boss fix only. The game stays in English. |
| **(B)** `... (ES) v1.3 (by Psicopompo)` | **All in one**: the final boss fix **plus jackic's Spanish translation**, inside the same patch. |

Each one comes in **two formats**: `.bps` (recommended) and `.ips`.


## What the boss fix changes

- **The saw is gone.** The object never comes to life in the fight: it is not
  drawn, it does not move and it cannot hit you.
- **The belt does not move and does not push you.** Neither the animation nor
  the pull.

That is **28 bytes** of game code. Nothing else is added or removed: no
graphics, no text, no tables, and the ROM keeps its original size.


## What it does NOT change

- The lasers and their rail (the Japanese version has them too).
- The boss armour-breaking animation (the Japanese version has it too).
- **The belt is still visible on the floor** (standing still). Removing its
  graphics as well would mean rebuilding the room's floor with the Japanese
  version's tiles, and for that we would need to see that room in the Japanese
  release, which uses a different floor. If you have a save file at the final
  boss **of the Japanese version**, please share it: with that we can look into
  making it identical.


## The ROM to patch

**Both** patches are applied to the clean, official western ROM (the dataset
dump, the one in circulation):

```
Wonder Boy in Monster World (USA, Europe).md     786,432 bytes (768 KB)
MD5     edba0bdb192d47712edbe0097f885f40
CRC32   1592F5B0
SHA-1   87a968f773c7e807e647c0737132457b06b78276
```

**Format matters:** it must be `.bin`, `.md` or `.gen` and exactly 786,432
bytes. If you ran it through SBWin, if it is a `.smd`, or if it carries a
copier header, it will not work: start again from the original dump.


## Results

| Patch applied | MD5 | CRC32 | SHA-1 |
|---|---|---|---|
| **(A)** boss fix | `3121a3a2dfe5cd66c75bfea6f8d27f36` | `05C7285D` | `515c6ab3d427f60bf85add23f60f7ba924d9a45a` |
| **(B)** all in one (ES) | `598d7ca135b3c003e401cd7fd1f80f2f` | `D812BF49` | `5bee68ec8ad15ecfa4ea17e72f0c28960d196fdd` |


## How to patch

With **Flips** (Windows, Linux, macOS), **Lunar IPS**, **MultiPatch** or any
other patching tool:

1. Open the tool and pick "apply patch".
2. Select the patch you want (the `.bps` is the recommended one).
3. Select your **unpatched** ROM.
4. Save the result.

With Flips, if you apply the patch to a ROM that is not the right one, it warns
you and refuses. That is the correct behaviour, not an error. If that happens,
check your ROM's CRC32: it must be `1592F5B0`.


## Notes

- The patch changes nothing outside the boss room: booting the game from
  scratch, the patched ROM and the original are pixel-for-pixel identical
  (except with patch (B), which of course also changes the text).
- It can be applied to a game already in progress; you will notice the change
  when you walk into the boss room.
- If you test with a savestate made **inside** the fight with the unpatched
  ROM, the saw is already created inside that savestate. Walk in normally (or
  load a save file) to see it properly.
- What about the SRAM-fixed variant of the ROM (the one that saves on a
  flashcart)? It differs from the one above by only **three header bytes**; the
  code is the same, so **the `.ips` also works with it**. The `.bps` does not,
  because it checks the whole file.


## Versions

- **v1.0** — the belt stopped animating, but still pushed you.
- **v1.1** — the push was fixed inside the fight, but still happened outside.
- **v1.2** — the push was fixed at the source. But the saw, while invisible,
  still existed and still hit you.
- **v1.3** — current version: the saw is properly disabled and the belt neither
  moves nor pushes. **Use this one.**


## Credits

- Final boss fix: **Psicopompo**.
- Spanish translation included in patch (B): **jackic**
  (http://jackicblog.blogspot.com/). He distributes it as a patch on his blog;
  this package ships it already applied inside patch (B) so you do not have to
  do it in two steps.
- *Wonder Boy in Monster World* is (c) **Sega** / **Westone**. This package
  contains no ROM at all: only the instructions to modify your own.
