# Wonder Boy V (Boss Fix) v1.3

**Final boss patch for *Wonder Boy in Monster World* (Mega Drive / Genesis)**
by **Psicopompo**.

Restores the western (UE) final boss to the Japanese version: **no saw
running across the floor and no conveyor belt** dragging you around.

The lasers, their rail, the boss armour and everything else are **untouched**:
those were already the same in both versions.


## What it changes

- **The saw is gone.** The object never comes to life in the fight: it is not
  drawn, it does not move and it cannot hit you.
- **The belt does not move and does not push you.** Neither the animation nor
  the pull.

That is 28 bytes of game code. Nothing else is added or removed: no graphics,
no text, no tables, and the ROM keeps its original size.


## What it does NOT change

- The lasers and their rail (the Japanese version has them too).
- The boss armour-breaking animation (the Japanese version has it too).
- **The belt is still visible on the floor** (standing still). Removing its
  graphics as well would mean rebuilding the room's floor with the Japanese
  version's tiles, and for that we would need to see that room in the
  Japanese version, which uses a different floor. If you have a save file (or
  a RetroArch savestate) at the final boss **of the Japanese version**, please
  share it: with that we can look into making it identical.


## Versions

The patch went through several versions, because every fix uncovered
something else. Changelog, in case you have an older file:

- **v1.0** — the belt stopped animating, but still pushed you.
- **v1.1** — the push was fixed inside the fight, but still happened outside.
- **v1.2** — the push was fixed at the source. But the saw, while invisible,
  still existed and still hit you.
- **v1.3** — current version: the saw is properly disabled and the belt
  neither moves nor pushes. **Use this one.**


## Files

Each version of the game has its own patch (there are two ROMs: the original
western one and its Spanish translation):

**Western (UE) ROM**

    Wonder Boy V (Boss Fix) v1.3 (by Psicopompo).ips
    Wonder Boy V (Boss Fix) v1.3 (by Psicopompo).bps

**Spanish ROM**

    Wonder Boy V (Boss Fix) (ES) v1.3 (by Psicopompo).ips
    Wonder Boy V (Boss Fix) (ES) v1.3 (by Psicopompo).bps

**IPS or BPS, which one?** The **BPS** is the recommended one: it checks that
the source ROM is the right one and refuses to patch if it is not. The **IPS**
checks nothing, but the same file works for both ROM versions.


## How to patch

Use **Flips** (Windows, Linux, macOS), **Lunar IPS**, **MultiPatch** or any
other patching tool:

1. Open the tool and pick "apply patch".
2. Select the patch (.bps recommended).
3. Select your **unpatched** ROM (see checksums below).
4. Save the result.

With Flips, if you apply the wrong patch for your ROM (say, the western patch
on the Spanish ROM), it warns you and refuses. That is the correct behaviour,
not an error.


## Checksums

**Western ROM, unpatched** (use this one with the western patch)

    Wonder Boy in Monster World (UE).bin          786,432 bytes
    MD5     1391725cc50671be68fc9dd405e19ac8
    CRC32   93153413
    SHA-1   481c0a3a61607cefc642992cd3faa18974834c94

**Spanish ROM, unpatched** (use this one with the Spanish patch)

    Wonder Boy in Monster World (es).bin          786,432 bytes
    MD5     4cd028dfcb2a4602ee6f6f3c13a28092
    CRC32   4EC0A307
    SHA-1   09bc1f04fa163459b780de65e4a55060791ed7b3

**Result after applying the western patch**

    MD5     fa6d35457c9f3418be588c93379d3ff3
    CRC32   8340E9FE
    SHA-1   99f601d285dcfb7e0077a72bea59ae889954ea01

**Result after applying the Spanish patch**

    MD5     a8c317d6fb7c70d3c53acb7328c830a7
    CRC32   5E957EEA
    SHA-1   6418d68ea27e2fa21a81fb8911146c44e38eba1a


## Notes

- The patch changes nothing outside the boss room: booting the game from
  scratch, the patched ROM and the original are pixel-for-pixel identical.
- It can be applied to a game already in progress; you will notice the change
  when you walk into the boss room.
- If you test with a savestate made **inside** the fight with the unpatched
  ROM, the saw is already created inside that savestate. Walk in normally
  (or load a save file) to see it properly.


## Credits

- Patch and testing by **Psicopompo**.
- *Wonder Boy in Monster World* is (c) **Sega** / **Westone**. This patch
  contains no copyrighted files: it is only the instructions to modify your
  own copy.
