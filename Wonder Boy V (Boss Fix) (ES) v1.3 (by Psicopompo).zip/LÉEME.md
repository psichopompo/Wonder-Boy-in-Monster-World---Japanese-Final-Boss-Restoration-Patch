# Wonder Boy V (Boss Fix) v1.3

**Parche del jefe final para *Wonder Boy in Monster World* (Mega Drive / Genesis)**
por **Psicopompo**.

Deja el jefe final de la versión occidental (UE) como el de la japonesa: **sin
la sierra que recorre el suelo y sin la cinta transportadora** que te arrastra.

Los láseres, su raíl, la armadura del jefe y todo lo demás **no se tocan**:
eso ya estaba igual en las dos versiones.


## Qué cambia

- **La sierra no aparece.** El objeto no llega a existir en el combate: no se
  dibuja, no se mueve y no puede tocarte.
- **La cinta no se mueve y no te arrastra.** Ni el dibujo ni el empuje.

Son 28 bytes del código del juego. No se añade ni se quita nada más: ni
gráficos, ni textos, ni tablas, ni el tamaño de la ROM.


## Qué NO cambia

- Los láseres y su raíl (están también en la japonesa).
- La animación de la armadura del jefe al romperse (está también en la
  japonesa).
- **La cinta sigue viéndose en el suelo** (quieta). Quitar también su dibujo
  obligaría a rehacer el suelo de la sala con los gráficos de la versión
  japonesa, y para eso hace falta ver esa sala en la versión japonesa, que
  usa un suelo distinto. Si alguien tiene una partida guardada (o un
  savestate de RetroArch) en el jefe final **de la versión japonesa**, que lo
  comparta: con eso se puede mirar de dejarla idéntica.


## Versiones

El parche ha pasado por varias versiones porque cada arreglo destapaba algo
nuevo. Historial, por si alguien tiene una versión antigua:

- **v1.0** — la cinta se quedaba quieta de imagen, pero seguía empujando.
- **v1.1** — se arregló el empuje dentro del combate, pero seguía apareciendo
  fuera de él.
- **v1.2** — se arregló el empuje en origen. Pero la sierra, sin dibujarse,
  seguía existiendo y golpeando.
- **v1.3** — versión actual: la sierra está desactivada de verdad y la cinta
  ni se mueve ni empuja. **Usad esta.**


## Ficheros

Cada versión del juego tiene su parche (hay dos versiones de la ROM: la
occidental original y su traducción al castellano):

**ROM occidental (UE)**

    Wonder Boy V (Boss Fix) v1.3 (by Psicopompo).ips
    Wonder Boy V (Boss Fix) v1.3 (by Psicopompo).bps

**ROM en castellano**

    Wonder Boy V (Boss Fix) (ES) v1.3 (by Psicopompo).ips
    Wonder Boy V (Boss Fix) (ES) v1.3 (by Psicopompo).bps

**IPS o BPS, ¿cuál uso?** El **BPS** es el recomendado: comprueba que la ROM
de origen es la correcta y avisa si no lo es. El **IPS** no comprueba nada,
pero vale lo mismo para las dos versiones de la ROM.


## Cómo parchear

Con **Flips** (Windows, Linux, macOS), **Lunar IPS**, **MultiPatch** o
cualquier otra herramienta de parcheo:

1. Abre la herramienta y elige «aplicar parche».
2. Selecciona el parche (.bps recomendado).
3. Selecciona tu ROM **sin parchear** (ver checksums abajo).
4. Guarda el resultado.

Con Flips, si aplicas el parche de la versión que no es (por ejemplo el
occidental sobre la ROM en castellano), avisa y no parchea. Eso es lo
correcto, no un error.


## Checksums

**ROM occidental sin parchear** (la que hay que usar con el parche occidental)

    Wonder Boy in Monster World (UE).bin          786.432 bytes
    MD5     1391725cc50671be68fc9dd405e19ac8
    CRC32   93153413
    SHA-1   481c0a3a61607cefc642992cd3faa18974834c94

**ROM en castellano sin parchear** (la que hay que usar con el parche ES)

    Wonder Boy in Monster World (es).bin          786.432 bytes
    MD5     4cd028dfcb2a4602ee6f6f3c13a28092
    CRC32   4EC0A307
    SHA-1   09bc1f04fa163459b780de65e4a55060791ed7b3

**Resultado con el parche occidental aplicado**

    MD5     fa6d35457c9f3418be588c93379d3ff3
    CRC32   8340E9FE
    SHA-1   99f601d285dcfb7e0077a72bea59ae889954ea01

**Resultado con el parche en castellano aplicado**

    MD5     a8c317d6fb7c70d3c53acb7328c830a7
    CRC32   5E957EEA
    SHA-1   6418d68ea27e2fa21a81fb8911146c44e38eba1a


## Notas

- El parche no toca nada fuera de la sala del jefe: arrancando el juego desde
  cero, la ROM parcheada y la original son idénticas píxel a píxel.
- Se puede aplicar sobre una partida ya empezada; el cambio se nota al entrar
  a la sala del jefe.
- Si pruebas con un savestate hecho **dentro** del combate con la ROM sin
  parchear, la sierra ya viene creada dentro del savestate. Entra jugando
  (o desde partida guardada) para verlo bien.


## Créditos

- Parche y pruebas: **Psicopompo**.
- Traducción al castellano de la ROM: **Psicopompo**.
- *Wonder Boy in Monster World* es de **Sega** y **Westone**. Este parche no
  incluye ningún fichero con copyright: solo instrucciones para modificar tu
  propia copia.
