# Wonder Boy V (Boss Fix) v1.4

**Parche del jefe final para *Wonder Boy in Monster World* (Mega Drive / Genesis)**
por **Psicopompo**.

Deja el jefe final de la versión occidental (UE) como el de la japonesa: **sin
la sierra que recorre el suelo y sin la cinta transportadora** que te arrastra.

Los láseres, su raíl, la armadura del jefe y todo lo demás **no se tocan**: eso
ya estaba igual en las dos versiones.


## Qué hay en este paquete

Dos parches, los dos se aplican sobre **la misma ROM limpia**:

| Parche | Qué hace |
|---|---|
| **(A)** `... v1.4 (by Psicopompo)` | Solo el arreglo del jefe final. El juego sigue en inglés. |
| **(B)** `... (ES) v1.4 (by Psicopompo)` | **Todo en uno**: el arreglo del jefe final **+ la traducción al castellano de jackic**, dentro del mismo parche. |

Cada uno va en **dos formatos**: `.bps` (recomendado) y `.ips`.


## Qué cambia el arreglo del jefe

- **La sierra no aparece.** El objeto no llega a existir en el combate: no se
  dibuja, no se mueve y no puede tocarte.
- **La cinta no se mueve y no te arrastra.** Ni el dibujo ni el empuje. Esto
  vale **solo para la sala del jefe final**: las cintas de la pirámide, que van
  con el mismo mecanismo, se quedan como estaban.

Son **28 bytes** del código del juego. No se añade ni se quita nada más: ni
gráficos, ni textos, ni tablas, ni el tamaño de la ROM.


## Qué NO cambia

- Los láseres y su raíl (están también en la japonesa).
- La animación de la armadura del jefe al romperse (está también en la
  japonesa).
- **La cinta sigue viéndose en el suelo** (quieta). Quitar también su dibujo
  obligaría a rehacer el suelo de la sala con los gráficos de la versión
  japonesa, y para eso hace falta ver esa sala en la versión japonesa, que usa
  un suelo distinto. Si alguien tiene una partida guardada en el jefe final
  **de la versión japonesa**, que la comparta: con eso se puede mirar de
  dejarla idéntica.


## La ROM que hay que parchear

Los **dos** parches se aplican sobre la ROM occidental limpia y oficial (el
volcado del dataset, que es el que circula):

```
Wonder Boy in Monster World (USA, Europe).md     786.432 bytes (768 KB)
MD5     edba0bdb192d47712edbe0097f885f40
CRC32   1592F5B0
SHA-1   87a968f773c7e807e647c0737132457b06b78276
```

**El formato importa:** tiene que ser `.bin`, `.md` o `.gen` y pesar 786.432
bytes exactos. Si la has convertido con SBWin, si es un `.smd` o si lleva
cabecera de copiador, no vale: vuelve a empezar desde el volcado original.


## El resultado

| Parche aplicado | MD5 | CRC32 | SHA-1 |
|---|---|---|---|
| **(A)** jefe final | `f1a79c5f664c9ad6de70511a027b2a4c` | `0C7C9A01` | `188802365153809553ce9ebdb13e06659d288bbb` |
| **(B)** todo en uno (ES) | `2bf2310a94d2d4b2e73a966ba55110a0` | `CC858F6A` | `cff7a6eb23cfd8477ade4f4628c67fe392ceb453` |


## El guardado: las dos variantes de ROM y los .srm

La ROM occidental tiene dos versiones en circulación que **solo se diferencian
en tres bytes de la cabecera**: los que declaran el tipo de chip de guardado.

| | Tipo | Quién la usa |
|---|---|---|
| `edba0bdb…` (CRC32 `1592F5B0`) | EEPROM | El volcado oficial del dataset. Es la base de los dos parches. |
| `1391725c…` (CRC32 `93153413`) | SRAM | La que lleva el arreglo de SRAM. **Es la que hace falta para guardar en un flashcart** (Everdrive y similares). |

**Cada tipo guarda de forma distinta, y un `.srm` hecho con uno no lo lee el
otro.** Medido: el mismo `.srm` cargado en la ROM del dataset (EEPROM) **no
muestra la opción CONTINUAR** en el menú; cargado en la variante con SRAM sí, y
entra en la partida.

Eso significa dos cosas:

- Si juegas en emulador y empiezas de cero, cualquiera de las dos te vale: el
  emulador guardará en el formato que corresponda.
- **Si quieres reutilizar un `.srm` que ya tienes, o si juegas en un flashcart,
  necesitas la variante de SRAM.** Se obtiene así:
  - con el **`.ips`**: aplícalo sobre tu ROM con arreglo de SRAM (el `.ips` solo
    toca código, así que deja los tres bytes de la cabecera como estaban);
  - o partiendo de la ROM del dataset y cambiando los tres bytes de la cabecera
    (`$1B2`, `$1B3`, `$1BB`) a `E8 40` y `01`.

Los `.bps` van atados a la ROM del dataset, así que **generan la variante
EEPROM**. Si necesitas SRAM, usa el `.ips`.


## Cómo parchear

Con **Flips** (Windows, Linux, macOS), **Lunar IPS**, **MultiPatch** o
cualquier otra herramienta:

1. Abre la herramienta y elige «aplicar parche».
2. Selecciona el parche que quieras (el `.bps` es el recomendado).
3. Selecciona tu ROM **sin parchear**.
4. Guarda el resultado.

Con Flips, si aplicas el parche sobre una ROM que no es la correcta, avisa y no
parchea. Eso es lo correcto, no un error. Si te pasa, comprueba el CRC32 de tu
ROM: tiene que ser `1592F5B0`.


## Notas

- El parche no toca nada fuera de la sala del jefe: arrancando el juego desde
  cero, la ROM parcheada y la original son idénticas píxel a píxel (excepto en
  el parche (B), que además cambia los textos, como es lógico).
- Se puede aplicar sobre una partida ya empezada; el cambio se nota al entrar a
  la sala del jefe.
- Si pruebas con un savestate hecho **dentro** del combate con la ROM sin
  parchear, la sierra ya viene creada dentro del savestate. Entra jugando (o
  desde partida guardada) para verlo bien.
- **La v1.3 detenía también las cintas de la pirámide.** Si vienes de la v1.3,
  actualiza a la v1.4: las de la pirámide vuelven a arrastrar.
- ¿Y la variante de la ROM con el arreglo de SRAM (la que guarda en
  Everdrive)? Solo se diferencia de la de arriba en **tres bytes de la
  cabecera**; el código es el mismo, así que **el `.ips` también le vale**. El
  `.bps` no, porque comprueba el fichero entero.


## Versiones

El parche ha tenido cinco versiones y cada una destapaba algo nuevo, así que las
copias antiguas están obsoletas:

- **v1.0** — la cinta se quedaba quieta de imagen, pero seguía empujando.
- **v1.1** — se arregló el empuje dentro del combate, pero seguía apareciendo
  fuera de él.
- **v1.2** — se arregló el empuje en origen. Pero la sierra, sin dibujarse,
  seguía existiendo y golpeando.
- **v1.3** — la sierra quedó desactivada de verdad y la cinta del jefe ni se
  mueve ni empuja. **Pero al detener esa cinta se detenían también las cintas
  transportadoras de la pirámide**, que van con el mismo mecanismo.
- **v1.4** — versión actual: el arreglo actúa **solo dentro de la sala del jefe
  final**, así que las cintas de la pirámide vuelven a arrastrar. **Usad esta.**


## Créditos

- Arreglo del jefe final: **Psicopompo**.
- Traducción al castellano incluida en el parche (B): **jackic**
  (http://jackicblog.blogspot.com/). Su traducción se distribuye como parche en
  su blog; este paquete la incluye ya aplicada dentro del parche (B) para no
  tener que darse dos pasos.
- *Wonder Boy in Monster World* es de **Sega** y **Westone**. Este paquete no
  incluye ninguna ROM: solo las instrucciones para modificar la tuya.
