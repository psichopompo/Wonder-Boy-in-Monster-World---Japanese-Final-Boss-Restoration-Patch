# Wonder Boy V (Boss Fix) v1.4

**Final boss patch for *Wonder Boy in Monster World* (Mega Drive / Genesis)**
by **Psicopompo**.

Restores the western (UE) final boss to the Japanese version: **no saw running
across the floor and no conveyor belt** dragging you around.

The lasers, their rail, the boss armour and everything else are **untouched**:
those were already the same in both versions.


## What is in this package

Two patches, both applied to the **same clean ROM**:

| Patch | What it does |
|---|---|
| **(A)** `... v1.4 (by Psicopompo)` | The final boss fix only. The game stays in English. |
| **(B)** `... (ES) v1.4 (by Psicopompo)` | **All in one**: the final boss fix **plus jackic's Spanish translation**, inside the same patch. |

Each one comes in **two formats**: `.bps` (recommended) and `.ips`.


## What the boss fix changes

- **The saw is gone.** The object never comes to life in the fight: it is not
  drawn, it does not move and it cannot hit you.
- **The belt does not move and does not push you.** Neither the animation nor
  the pull. This applies **only to the final boss room**: the pyramid conveyor
  belts, which use the same mechanism, are left alone.

That is **28 bytes** of game code. Nothing else is added or removed: no
graphics, no text, no tables, and the ROM keeps its original size.


## What it does NOT change

- The lasers and their rail (the Japanese version has them too).
- The boss armour-breaking animation (the Japanese version has it too).
- **The belt is still visible on the floor** (standing still). Removing its
  graphics as well would mean rebuilding the room's floor with the Japanese
  version's tiles, and for that we would need to see that room in the Japanese
  release, which uses a different floor. If you have a save file at the final
  boss **of the Japanese version**, please share it: with that we can look into
  making it identical.


## The ROM to patch

**Both** patches are applied to the clean, official western ROM (the dataset
dump, the one in circulation):

```
Wonder Boy in Monster World (USA, Europe).md     786,432 bytes (768 KB)
MD5     edba0bdb192d47712edbe0097f885f40
CRC32   1592F5B0
SHA-1   87a968f773c7e807e647c0737132457b06b78276
```

**Format matters:** it must be `.bin`, `.md` or `.gen` and exactly 786,432
bytes. If you ran it through SBWin, if it is a `.smd`, or if it carries a
copier header, it will not work: start again from the original dump.


## Results

| Patch applied | MD5 | CRC32 | SHA-1 |
|---|---|---|---|
| **(A)** boss fix | `f1a79c5f664c9ad6de70511a027b2a4c` | `0C7C9A01` | `188802365153809553ce9ebdb13e06659d288bbb` |
| **(B)** all in one (ES) | `2bf2310a94d2d4b2e73a966ba55110a0` | `CC858F6A` | `cff7a6eb23cfd8477ade4f4628c67fe392ceb453` |


## Saving: the two ROM variants and .srm files

There are two western ROM versions in circulation that differ only in **three
header bytes**: the ones declaring the save-chip type.

| | Type | Who uses it |
|---|---|---|
| `edba0bdb…` (CRC32 `1592F5B0`) | EEPROM | The official dataset dump. It is the base for both patches. |
| `1391725c…` (CRC32 `93153413`) | SRAM | The one carrying the SRAM fix. **This is the one you need to save on a flashcart** (Everdrive and the like). |

**The two types save differently, and a `.srm` made with one will not load in
the other.** Measured: the same `.srm` loaded into the dataset ROM (EEPROM)
**does not even show the CONTINUE option** in the menu; loaded into the
SRAM-fixed variant it does, and the game loads the save.

So:

- If you play on an emulator and start fresh, either variant works: the
  emulator will save in the matching format.
- **If you want to reuse an existing `.srm`, or if you play on a flashcart, you
  need the SRAM variant.** Get it by:
  - using the **`.ips`**: apply it to your SRAM-fixed ROM (the `.ips` only
    touches code, so the three header bytes stay as they were);
  - or taking the dataset ROM and changing the three header bytes (`$1B2`,
    `$1B3`, `$1BB`) to `E8 40` and `01`.

The `.bps` files are tied to the dataset ROM, so they produce the **EEPROM**
variant. If you need SRAM, use the `.ips`.


## How to patch

With **Flips** (Windows, Linux, macOS), **Lunar IPS**, **MultiPatch** or any
other patching tool:

1. Open the tool and pick "apply patch".
2. Select the patch you want (the `.bps` is the recommended one).
3. Select your **unpatched** ROM.
4. Save the result.

With Flips, if you apply the patch to a ROM that is not the right one, it warns
you and refuses. That is the correct behaviour, not an error. If that happens,
check your ROM's CRC32: it must be `1592F5B0`.


## Notes

- The patch changes nothing outside the boss room: booting the game from
  scratch, the patched ROM and the original are pixel-for-pixel identical
  (except with patch (B), which of course also changes the text).
- It can be applied to a game already in progress; you will notice the change
  when you walk into the boss room.
- If you test with a savestate made **inside** the fight with the unpatched
  ROM, the saw is already created inside that savestate. Walk in normally (or
  load a save file) to see it properly.
- **v1.3 stopped the pyramid belts too.** If you are coming from v1.3, update
  to v1.4: the pyramid belts push again.
- What about the SRAM-fixed variant of the ROM (the one that saves on a
  flashcart)? It differs from the one above by only **three header bytes**; the
  code is the same, so **the `.ips` also works with it**. The `.bps` does not,
  because it checks the whole file.


## Versions

The patch went through several versions because each fix uncovered something
else. The history is included here in case anyone still has an older version:

- **v1.0** — the belt stopped animating, but still pushed you.
- **v1.1** — the push was fixed inside the fight, but still happened outside.
- **v1.2** — the push was fixed at the source. But the saw, while invisible,
  still existed and still hit you.
- **v1.3** — the saw was properly disabled and the belt neither moved nor
  pushed. **But stopping that belt also stopped the conveyor belts in the
  pyramid**, which run on the same mechanism.
- **v1.4** — current version: the fix now acts **only inside the final boss
  room**, so the pyramid belts push again. **Use this one.**


## Credits

- Final boss fix: **Psicopompo**.
- Spanish translation included in patch (B): **jackic**
  (http://jackicblog.blogspot.com/). He distributes it as a patch on his blog;
  this package ships it already applied inside patch (B) so you do not have to
  do it in two steps.
- *Wonder Boy in Monster World* is (c) **Sega** / **Westone**. This package
  contains no ROM at all: only the instructions to modify your own.
